# Healthcare CAA dataset - Synthea subset

Selected 7 November 2026 for the Healthcare Patient Record System CAA.

## Sources and citation
Official download page: https://synthetichealth.github.io/downloads.html
Downloaded archive: https://synthetichealth.github.io/synthea-sample-data/downloads/latest/synthea_sample_data_csv_latest.zip
Official field dictionary: https://github.com/synthetichealth/synthea/wiki/CSV-File-Data-Dictionary
Recommended reference: Walonoski, J., et al. (2018). Synthea: An approach, method, and software mechanism for generating synthetic patients and the synthetic electronic health care record. Journal of the American Medical Informatics Association, 25(3), 230-238. https://doi.org/10.1093/jamia/ocx079
The official download page permits unrestricted secondary use. All patient records are synthetic, not actual patients. They are US-oriented simulated records, not representative Irish patient data.

## What to use
- patients.csv: 111 synthetic patients; selected demographic fields only.
- encounters.csv: 5,059 visits; selected fields only.
- conditions.csv: 3,387 condition/finding records. Not every condition is a confirmed disease diagnosis; preserve descriptions/codes.
- lab_results.csv: 19,784 observations selected using CATEGORY == laboratory. These are results/measurements, not a lab-order table. Preserve code, description, value, units and type; not all values must be numeric.

This is ONE dataset distributed across FOUR related CSV tables, not four competing datasets. Patients join via patients.Id = PATIENT; encounters via encounters.Id = ENCOUNTER. Do not combine unrelated rows by row number. Conditions and observations have no supplied unique row ID: generate stable import IDs before implementing independent record updates. No clinical values have been altered. Excluded unnecessary billing/claims, medications and other tables; omitted identifying-like synthetic fields, geography and costs from selected tables.

## Fit to brief and marking scheme
Patient records, conditions and lab results directly cover the topic's required data. Encounters organise patient histories. Load equivalent records into relational and document models for the required comparison. This sample supports a starting prototype and workload testing, not a claim of large-scale performance. For scaling tests, generate larger Synthea populations or clearly label any controlled replication and remap related identifiers consistently.
Privacy, staff authentication/permissions, auditability and recovery are APPLICATION/DATABASE responsibilities still to implement and test. This dataset does not implement them. Create a small synthetic staff fixture separately. Do not infer medical abnormality or perform clinical decisions from these records.

## Validation
See validation.json. Checked unique patient/encounter IDs, patient references, encounter references, patient/encounter agreement, and event dates not before patient birth. These checks passed for the included data. This is not exhaustive clinical or temporal validation. Record any later cleaning/filtering and apply it identically to both model candidates.

## Brief reference
Local source: Data architecture CA-v1.pdf, pages 1-3; Topic 7, architectural choices 45%, performance 20%, reliability 20%, quality/presentation 15%. Report and present actual design choices and measured evidence. Downloading a dataset does not complete those requirements.
